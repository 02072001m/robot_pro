# How to get started

1. Access the following directory
   - `C:\Users\<user name>\AppData\Local\Programs\Python\Python<version>\Lib`
2. make a new directory and name it `gym` (or whatever)
3. git clone https://github.com/openai/gym.git
4. cd gym
   - `current directory is C:\Users\<user name>\AppData\Local\Programs\Python\Python<version>\Lib\gym\gym`
5. `pip install -e .`
6. run `python -u main.py`